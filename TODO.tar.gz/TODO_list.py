Original IDLE todo:, much of it now outdated:
============================================
TO DO:

import TODO_James_teaching
import tomerge_james_todo
import James_todo

    # TODO: condense /Users/owner/Documents/iCloud sbox/jamesmk6/tomerge_james_todo.py and
    # /Users/owner/Documents/iCloud sbox/jamesmk6/TODO_list.py and
# /Users/owner/Documents/iCloud sbox/jamesmk6/James_todo.py and 
    #/Users/owner/Documents/iCloud sbox/jamesmk6/TODO_James_teaching.py into one script.

# import eVOLUTIOn
# file for ML"
james_todo_master = {
- [ ] "TODO:300  ("") create a dashboard of how popular a software package is for different areas. Operating systems, pc vs mac, typical google analytics stuff. growth of or drop in Android vs mac market share. drop or growth of top 65 stocks on Nasdac and another cloud for the nyse with a fortone 400 overlay")

- [ ] "TODO:025  ("") being able to vectorize your decisions in a three dimensional space isnt something that has been done before, running emotionalradar.py will give you the first multilayer emtional status of your employee.")

- [ ] "TODO:010  ("") this include all 21 APA Emotions and SuperEmotions.")

- [ ] "TODO:007  ("") Imagine being able to accurately guage your employees responses in real time, like an emotional giegercounter for radioactive emotions like rage, depression, x, y and over time z and more.")

# create scrapable way to pull phrases from code into a blog... hmmmmm.
- [ ] "TODO:050  ("") from what I've found currently is that my experience into the world of code is much like operating a tunnel boring machine.")
- [ ] "TODO:051  ("")  learn ipconfig
- [ ] "TODO:052  ("")  spend 6 hours per month practicing github commands, process and updating my repos
- [ ] "TODO:  ("")  setup and run http://jelly.codes/articles/python-virtualenv-from-within-python/
- [ ] "TODO:  ("")  import https://pypi.python.org/pypi/mekk.xmind/0.4.0
- [ ] "TODO:  ("")  import plot # and start plotting outcomes from AWS instance",
- [ ] "TODO:  ("")  import loop3 #to scan for user interaction and user sql backend, AWS or else",
- [ ] "TODO:  ("")  import travis.ci
- [ ] "TODO:  ("")  Add https://inch-ci.org/github/datatalking/James?pending_build=314726
- [ ] "TODO:  ("")  Add https://github.com/datatalking/repo-badges
- [ ] "TODO:  ("")  Configure jamesalt.py
- [ ] "TODO:  ("")  Add multi-gpu Context (http://on-demand.gputechconf.com/gtc-express/2011/presentations/cuda_webinars_multi_gpu.pdf)
- [ ] "TODO:  ("")  Add reduction kernels for mean and sum along the axis
- [ ] "TODO:  ("")  Add Cython routine for reducing size
- [ ] "TODO:  ("")  Add compiler functionality for more flexible code generation
- [ ] "TODO:  ("")  Add max margin cost function
- [ ] "TODO:  ("")  use device api for dropout instead of host api
- [ ] "TODO:  ("")  add license
- [ ] "TODO:  ("")  write readme
- [ ] "TODO:  ("")  add gradient clipping page 5/6 http://arxiv.org/pdf/1308.0850v5.pdf
- [ ] "TODO:  ("")  Review all matrices that go into wait_matrices, it can cause a lot of nasty bugs, that hard to reproduce and catch
- [ ] "TODO:  ("")  Implement Depth-gated LSTM (http://arxiv.org/pdf/1508.03790.pdf), Vanilla RNN and GRU
- [ ] "TODO:  ("")  Add inplace dropout
- [ ] "TODO:  ("")  Add function print ("Jamestodolist", "be able to scan its outer connected and unconnected ports in all of the programs released on a say pipy which in itself has over90 different sub programs and that was as of 2016."
- [ ] "TODO:  ("")  Add function print ("setup james to scrape a directory for info, scrap a pdf and analyse for, scrap a webpage and pull it into be considered [research]. I think perhaps a big reason that most companies are failing to innovate is ['a_wait_and_see', 'attitude'] vs ['start_and_innovate_today.'] I think you should have a working prototype up within two weeks or you don't have an experienced developer.")
- [ ] "TODO:  ("")  Add function to receive info from user load userdata into 10 filter
- [ ] "TODO:  ("")  Add function to scan forpersonal reccomendation via james filter, display
- [ ] "TODO:  ("")  Add function to setup kimbot to scan twitter andwork it to be most retweeted
- [ ] "TODO:  ("")  Add function we compiled andare studying 137 sources for personal assistants", "concierge services", "academic ai papers", "existing and theoretical artificial intellgence", "butlering and valets.", "", "look for ways of importing type1py for opening sequence add a funcky static looking page as error", "TODO: how do i create a todo: list searcher that scans software for tags and creates an ouput file and prints to screen.", "[Hilgart Offering] #CHASE #BOA #NYL #COMCAST #Deutsche Bank"
- [ ] "TODO:  ("") train voice on jdouglasedward, neil degrass, carl sagan.carl",
- [ ] "TODO:  ("") another project todo, use ocr anddefactored code",
- [ ] #"https://books.google.com/books?id=wFohJsLyEb8C&pg=PA65&lpg=PA65&dq=douglas+edwards+questions+are+the+answers+words&source=bl&ots=0r-YwOAN-d&sig=m3423GXRa5tTBw9vlC5RCQ8Goy0&hl=en&sa=X&ved=0ahUKEwiv3tXjsYfRAhUO5mMKHXGDDTgQ6AEINDAD#v=onepage&q=douglas%20edwards%20questions%20are%20the%20aswers%20words&f=false",
- [ ] "TODO:  ("") asa view source then copy that computer code asthe other side of the coin. Then create aprogram that takes source 1 and convert it into state and compare that state with 1 or 2.",
- [ ] "TODO:  ("") receive info fromuser load userdata into 10 filter",
- [ ] "TODO:  ("") scan forpersonal reccomendation via james filter, display",
- [ ] "TODO:  ("") use 60 minutes asa markov trainer on how to talk withsomeone",
- [ ] "TODO:  ("") analyze converstiaon interms of tone, context, sentiment",
# "could establish a we would like a sponsor for server time in developing, in return we will do the data programing no charge. Monthlyrate(1k, 5k, 10k), ("$1000 a month") = (1k), # $5000 a month = (5k), # $10,000 a month = (10k), # (1k, 5k, 10k) print(statevalue)",
- [ ] "TODO:  ("") voicetraining",
- [ ] "TODO:  ("") Print This program will soon run in the cloud on your phone. Would you like to be notified of changes.",
- [ ] "TODO:  ("") ifinput = yes",
- [ ] "TODO:  ("") then data to Mailchimp API = UpdateClientFile" "UpdateClientFile = true",
- [ ] "TODO:  ("") as a guide with me having an always ready battery to use it.",
- [ ] "TODO:  ("") class Saying: def __init__(self, radius): for i in range(1, 10):, if (i & 1) == 0: continue", "1 If you love something give it away",
- [ ] "TODO:  ("") print 2[DailyGeniusVote]+{starkwouldsay}",
- [ ] "TODO:  ("") print 3 to lose the fear, practice losing that which you love the most",
- [ ] "TODO:  ("") print 4 Bruce Lee, fear of the unknown can be your ally if you focus the mind",
- [ ] "TODO:  ("") print 5RandomArtofWarQuote",
- [ ] "TODO:  ("") def CurrentTODO:",
- [ ] "TODO:  ("") piano things to you ups store",
- [ ] "TODO:  ("") move my car",
- [ ] "TODO:  ("") list of whats in her storage",
- [ ] "TODO:  ("") my storage list",
- [ ] "TODO:  ("") ikea bed and mattress",
- [ ] "TODO:  ("") class aknowledge: def __init__(self, state, datetime): positive(yes sir, certainly sir, of course sir) or else",
- [ ] "TODO:  ("") contact TS and talk about an electronic album, use a synonnym or alias so she understands the reach she has that is not being harnesses.",
- [ ] "TODO:  ("") add mbti as a functional filter for users_file",
- [ ] "TODO:  ("") add notes on what Scikit-learn requires:",
- [ ] "TODO:  ("") Python (>= 2.6 or >= 3.3)",
- [ ] "TODO:  ("") NumPy (>= 1.6.1)",
- [ ] "TODO:  ("") SciPy (>= 0.9)",
- [ ] "TODO:  ("") import .yml script from terminal",
- [ ] "TODO:  ("") setup travis.ci a yml automater",
- [ ] "TODO:  ("") import yaml",
- [ ] "TODO:  ("") content = open('enviroment.ym.').read()",
- [ ] "TODO:  ("") print(type(content) it is a string",
- [ ] "TODO:  ("") y = yaml.load(content)",
- [ ] "TODO:  ("") print(type(y)) it is a scring",
- [ ] "TODO:  ("") print(y)",
- [ ] "TODO:  ("") top ten categories of relationships",
- [ ] "TODO:  ("") top list of things_to_do",
- [ ] "TODO:  ("") top_priorities",
- [ ] "TODO:  ("") nightly_printed_function",
- [ ] "TODO:  ("") what is this list below?",
- [ ] "TODO:  ("") ERROR if username = [cas]",
- [ ] "TODO:  ("") print('Hello, Cas. Andrew has been telling me about how he is looking forward to the goat rocks climb with his older brother. Thats all I know for now', person)",
- [ ] "TODO:  ("") create a prompt every so often that establishes a readout saying [you should be doing xyzthing] could pull this from [travis]",
- [ ] "TODO:  ("") ERROR import jamesTimer.py",
- [ ] "TODO:  ("") is there a way to add a time_spent the same way travis does content_changed",
- [ ] "TODO:  ("") read http://docs.python-guide.org/en/latest/writing/style/",
- [ ] "TODO:  ("") chron job for turning on the pc == travis.yml",
- [ ] "TODO:  ("") reply00###-",
- [ ] "TODO:  ("") onramp###- the steps to increase adoption and integrate user of python_function_used##",
- [ ] "TODO:  ("") python_function_used - a list of all python functions used indexed by name",
- [ ] "TODO:  ("") python_function_total - a master_python_functions",
- [ ] "TODO:  ("") python_functions_unused - equals master_python_functions minus python",
- [ ] "TODO:  ("") purpose###if function improves the speed of purpose then +1",
- [ ] "TODO:  ("") powerloss###- self image### started",
- [ ] "TODO:  ("") hardware###- hardware issues#",
- [ ] "TODO:  ("") swot###- strenghts weakness opportunity threats",
- [ ] "TODO:  ("") errorcon####- error control and alignment",
- [ ] "TODO:  ("") mlearn###- machine learning",
- [ ] "TODO:  ("") nnet###- nueral network",
- [ ] "TODO:  ("") count items in james folder = export #of files, #not used in 30 days, #of items to work on, #log time in it.",
- [ ] "TODO:  ("") create a way that when it reads it, it also displays the words typwriter style, instead of a flash you do it leter by letter or char by char.",
- [ ] "TODO:  ("") create a way that each night I am adding to his code by adding a module that remembers when it was added.",
- [ ] "TODO:  ("") create a sentience quality within James.",
- [ ] "TODO:  ("") user first name and last name.",
- [ ] "TODO:  ("") remember user.",
- [ ] "TODO:  ("") count number of times and when jamesroutine.py is run.",
- [ ] "TODO:  ("") run jamesTimer.py",
- [ ] "TODO:  ("") teach james to sing taylor swift songs with his voice.",
- [ ] "TODO:  ("") allow for voice slowdowns with os.system say this options?",
- [ ] "TODO:  ("") import lyrics via xml file from itunes.",
- [ ] "TODO:  ("") remembers the username",
- [ ] #####{% set version = "7.3" %}
- [ ] #jinja
- [ ] #####  Package:
- [ ] #####  name: example
- [ ] #####  version: {{ version }} #why in
- [ ] ## DO NOT CHANGE THE ORDER OF the lines below.
- [ ] "TODO:  ("") define function - MLong",